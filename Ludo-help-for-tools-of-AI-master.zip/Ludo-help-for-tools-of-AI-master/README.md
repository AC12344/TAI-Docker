# Ludo Help for Tools of AI

The C++ Ludo code on Black Board is full of bugs and poor software design.</br>
To see the bugs please explore the content of the Unittest folder.</br>
To get the bug-fixed, design and speed improved code please explore the content of the Domain-Code folder.</br>
The Players folder contains some semi-smart Ludo player implementations to teset your own AI player against.</br>

Enjoy
