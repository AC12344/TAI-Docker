The Q-learning AI agent implemented for the Tools of AI exam paper assignment together with a Q-table trained by the agent over 1,000,000 games of self-play with a learning rate of alpha = 0.05
