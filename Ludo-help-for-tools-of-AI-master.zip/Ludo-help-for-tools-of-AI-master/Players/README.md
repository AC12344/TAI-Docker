This folder contains the code for 1 random and 3 semi smart Ludo players.<br/>
Most of the analysing logic has been extracted into a helper class called 'move_logic'<br/>
<strong>'player_random_safe'</strong> wins approx. 57% of games in 2-vs-2 play against 'player_random'<br/>
<strong>'player_fast'</strong> wins approx. 77% of games in  2-vs-2 play against 'player_random_safe'<br/>
<strong>'player_aggro_fast'</strong> wins approx. 70% of games in 2-vs-2 play against 'player_fast'<br/>

Enjoy
