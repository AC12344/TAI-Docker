#ifndef POSITIONS_AND_DICE_H
#define POSITIONS_AND_DICE_H

struct positions_and_dice
{
    int dice;
    int position[16];

    positions_and_dice() {}
};

#endif // POSITIONS_AND_DICE_H
